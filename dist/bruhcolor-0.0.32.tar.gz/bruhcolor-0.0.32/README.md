# bruhcolor - The 255 Color formatting for terminal in Python
